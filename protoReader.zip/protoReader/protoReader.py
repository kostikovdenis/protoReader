import sys
from working import description_pb2 as proto

data = open(".\working\working.pb", "rb").read()
msg = proto.Envelop()
msg.ParseFromString(data)

with open(".\output\output.txt", "w") as f:
    f.write(str(msg))
